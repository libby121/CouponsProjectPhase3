export enum Category {
    Food,Beauty,Home,Concerts,Travel,Pets

}
